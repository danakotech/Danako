#include <string>
thread_local std::string foo;
